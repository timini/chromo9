SETTINGS = {
            'DB':{
                  'USER':'root',
                  'LOCATION':'localhost',
                  'PORT':'3306',
                  'DATABASE_NAME':'chromo9',
                  },
            }
