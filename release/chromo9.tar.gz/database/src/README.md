The default genbank database structure is contained in the default_schema

custom_schema is the database used by this project
