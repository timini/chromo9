Author: Tim Richardson

tasks:
database design
data extraction and parsing
data cleaning
