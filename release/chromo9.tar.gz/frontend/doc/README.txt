Author: George Seed

Tasks:
Web front end design
User use cases
Integration to middle layer
User testing
